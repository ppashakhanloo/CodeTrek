

def add_filter(prev_filter):

    def filter(path):
        if (path.endswith('.tmpl') or path.endswith('.spt')):
            return True
        return prev_filter(path)
    return filter
