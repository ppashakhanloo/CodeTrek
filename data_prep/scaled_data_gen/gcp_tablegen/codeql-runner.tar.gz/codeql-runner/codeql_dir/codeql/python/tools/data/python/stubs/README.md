This folder contains stubs for commonly used Python libraries, which have
the same interface as the original libraries, but are more amenable to
static analysis. The original licenses are noted in each subdirectory.
