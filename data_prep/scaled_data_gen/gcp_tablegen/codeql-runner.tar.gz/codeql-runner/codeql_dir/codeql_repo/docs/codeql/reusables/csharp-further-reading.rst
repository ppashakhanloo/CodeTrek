- `CodeQL queries for C# <https://github.com/github/codeql/tree/main/csharp/ql/src>`__
- `Example queries for C# <https://github.com/github/codeql/tree/main/csharp/ql/examples>`__
- `CodeQL library reference for C# <https://codeql.github.com/codeql-standard-libraries/csharp/>`__

