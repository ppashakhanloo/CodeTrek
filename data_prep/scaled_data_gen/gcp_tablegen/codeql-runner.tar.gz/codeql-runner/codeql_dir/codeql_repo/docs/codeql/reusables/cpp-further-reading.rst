- `CodeQL queries for C and C++ <https://github.com/github/codeql/tree/main/cpp/ql/src>`__
- `Example queries for C and C++ <https://github.com/github/codeql/tree/main/cpp/ql/examples>`__
- `CodeQL library reference for C and C++ <https://codeql.github.com/codeql-standard-libraries/cpp/>`__

