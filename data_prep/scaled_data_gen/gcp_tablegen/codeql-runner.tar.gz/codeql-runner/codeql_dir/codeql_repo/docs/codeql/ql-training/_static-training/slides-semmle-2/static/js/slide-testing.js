require(['order!modernizr.custom.45394',
         'order!prettify/prettify', 'order!hammer', 'order!slide-controller',
         'order!slide-deck',
         'order!slide-deck-instantiate'], function(someModule) {

});
