To download a database from LGTM.com: 

#. Log in to `LGTM.com <https://lgtm.com/>`__.
#. Find a project you're interested in and display the Integrations tab (for example, `Apache Kafka <https://lgtm.com/projects/g/apache/kafka/ci/>`__).
#. Scroll to the **CodeQL databases for local analysis** section at the bottom of the page.
#. Download databases for the languages that you want to explore.