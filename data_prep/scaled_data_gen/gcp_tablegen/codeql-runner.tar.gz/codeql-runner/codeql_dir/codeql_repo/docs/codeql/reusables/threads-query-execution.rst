``--threads``: optionally, the number of threads to use when running queries.
The default option is ``1``. You can specify more threads to speed up query
execution. Specifying ``0`` matches the number of threads to the number of logical processors.