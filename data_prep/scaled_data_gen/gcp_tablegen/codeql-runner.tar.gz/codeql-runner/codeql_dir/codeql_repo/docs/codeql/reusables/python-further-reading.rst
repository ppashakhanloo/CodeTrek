- `CodeQL queries for Python <https://github.com/github/codeql/tree/main/python/ql/src>`__
- `Example queries for Python <https://github.com/github/codeql/tree/main/python/ql/examples>`__
- `CodeQL library reference for Python <https://codeql.github.com/codeql-standard-libraries/python/>`__

