The CodeQL command-line interface (CLI) is used to create databases for 
security research. You can query CodeQL databases directly from the command line 
or using the Visual Studio Code extension.
