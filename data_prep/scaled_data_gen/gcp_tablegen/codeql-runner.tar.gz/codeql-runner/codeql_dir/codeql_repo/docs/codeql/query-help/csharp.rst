CodeQL query help for C#
========================

.. include:: ../reusables/query-help-overview.rst

For shorter queries that you can use as building blocks when writing your own queries, see the `example queries in the CodeQL repository <https://github.com/github/codeql/tree/main/csharp/ql/examples>`__.

.. include:: toc-csharp.rst