.. list-table::
   :header-rows: 1
   :widths: 50 50

   * - Language
     - Identifier
   * - C/C++ 
     - ``cpp``
   * - C# 
     - ``csharp``
   * - Go
     - ``go``
   * - Java 
     - ``java``
   * - JavaScript/TypeScript
     - ``javascript``
   * - Python
     - ``python``