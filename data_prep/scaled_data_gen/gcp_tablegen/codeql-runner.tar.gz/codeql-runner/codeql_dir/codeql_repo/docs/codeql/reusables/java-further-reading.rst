- `CodeQL queries for Java <https://github.com/github/codeql/tree/main/java/ql/src>`__
- `Example queries for Java <https://github.com/github/codeql/tree/main/java/ql/examples>`__
- `CodeQL library reference for Java <https://codeql.github.com/codeql-standard-libraries/java/>`__

