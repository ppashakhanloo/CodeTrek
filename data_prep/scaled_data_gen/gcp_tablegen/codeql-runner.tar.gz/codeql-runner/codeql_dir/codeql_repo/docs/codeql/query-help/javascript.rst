CodeQL query help for JavaScript
================================

.. include:: ../reusables/query-help-overview.rst

For shorter queries that you can use as building blocks when writing your own queries, see the `example queries in the CodeQL repository <https://github.com/github/codeql/tree/main/javascript/ql/examples>`__.

.. include:: toc-javascript.rst