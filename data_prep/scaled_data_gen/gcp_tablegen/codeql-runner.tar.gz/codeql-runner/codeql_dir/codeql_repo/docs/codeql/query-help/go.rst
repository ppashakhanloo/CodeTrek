CodeQL query help for Go
========================

.. include:: ../reusables/query-help-overview.rst

For shorter queries that you can use as building blocks when writing your own queries, see the `example queries in the CodeQL for Go repository <https://github.com/github/codeql-go/tree/main/ql/examples>`__.

.. include:: toc-go.rst
