CodeQL training and variant analysis examples
=============================================

.. toctree::
   :glob:
   :maxdepth: 1
   :hidden:

   *
   */**