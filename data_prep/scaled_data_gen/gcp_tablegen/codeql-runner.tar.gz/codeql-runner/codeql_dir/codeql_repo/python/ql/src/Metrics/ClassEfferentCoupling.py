class X:
    
    def iUseY(y):
        y.doStuff()

    def soDoY():
        return Y()

    def iUseZ(z1, z2):
        return z1.combine(z2)
