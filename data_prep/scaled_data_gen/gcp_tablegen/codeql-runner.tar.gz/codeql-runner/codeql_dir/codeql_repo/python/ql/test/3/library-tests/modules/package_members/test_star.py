#Importing the package will execute its __init__.py module, filling in the namespace for the package.

from test_package import *