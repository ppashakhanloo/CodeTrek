print(__file__.split("entry_point")[1])
import namespace_package.namespace_package_module
