import module1
import module2
import module1 # Duplicate import
