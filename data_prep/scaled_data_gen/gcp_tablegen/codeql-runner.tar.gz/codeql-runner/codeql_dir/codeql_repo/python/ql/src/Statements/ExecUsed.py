
to_execute = get_untrusted_code()
exec to_execute
