
def increment_and_show(x):
    ++x
    x.show
