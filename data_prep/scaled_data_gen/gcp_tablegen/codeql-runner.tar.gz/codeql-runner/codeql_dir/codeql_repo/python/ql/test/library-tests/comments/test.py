
def e():
    #A real comment
    some_code()
    x = y
    some_more_code()
    "Ignore single commented out lines as it is too difficult to tell whether they are code"
    #class C(object):
    a_bit_more_code()
    return 1

def f(x):
    if x:
        do_something()
    #else:
    #    do_something_else()
    
# Some non-code comments.    
# Space immediately after scope start and between functions.
#    
#class CommentedOut:
#    
#    def __init__(self):

#       pass
#    
#    def method(self):
#
#        pass
#    
#def g(y):
#    assert y  
#    with y:
#        # Commented out comment
#        if y:
#             do_something()
#        else:
#             do_something_else()
#               
#def h(z):
#    '''Doc string
#    '''
#    # Commented out comment
#    
#    followed_by_space()

#    
#    more_code()
    
#def j():
#    """ Doc string """
#    pass
        
#def k():
#
#    """ Doc string """
#    pass
    
#def l():
#
#    """ 
#      Doc string 
#    """
#
#    pass
    
#
#
#
#
#def m():
#    pass
#
#
#  
some_code_to_break_up_comments()

#with x:
#    pass
#try:
#    call()
#except Exception:
#    pass
#except:
#    pass

def a_function_to_break_up_comments():
    pass

# An example explaining
# something which contains 
# the following code:
#
#  def f():
#      call()
#      x.y = z
#      return x
#


def foo():
    # type: () -> None
    pass