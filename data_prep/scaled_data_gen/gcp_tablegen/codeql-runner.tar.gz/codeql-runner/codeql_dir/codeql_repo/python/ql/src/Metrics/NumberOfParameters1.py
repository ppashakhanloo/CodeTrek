def print_annotation(message, line, offset, length):
    print("Message: " + message)
    print("Line: " + line)
    print("Offset: " + offset)
    print("Length: " + length)