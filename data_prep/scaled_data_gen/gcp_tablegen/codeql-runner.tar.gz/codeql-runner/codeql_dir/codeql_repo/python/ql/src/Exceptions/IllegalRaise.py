#Cannot raise an int, even if we want to
def raise_int():
    #Will raise a TypeError
    raise 4

