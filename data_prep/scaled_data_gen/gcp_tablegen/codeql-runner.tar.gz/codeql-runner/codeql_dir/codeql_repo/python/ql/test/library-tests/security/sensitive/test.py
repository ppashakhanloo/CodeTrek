
from not_found import get_passwd, account_id

def get_password():
    pass

def get_secret():
    pass

def fetch_certificate():
    pass

def encrypt_password(pwd):
    pass

get_password()
get_passwd()
get_secret()
fetch_certificate()
account_id()
safe_to_store = encrypt_password(pwd)
