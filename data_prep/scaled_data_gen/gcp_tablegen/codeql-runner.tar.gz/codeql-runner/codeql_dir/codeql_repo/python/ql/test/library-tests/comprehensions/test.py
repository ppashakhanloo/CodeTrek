
[   i+j
    for i in range(1)
    for j in range(2)
]

{
    x * x for x in seq
}

{
    y.attr : z()
    for y, z in
    mapping
}
