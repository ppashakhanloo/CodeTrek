
# Base class method
def runsource(self, source, filename="<input>", symbol="single"):
    ... # Definition
    
    
# Extend base class method
def runsource(self, source):
    ... # Definition