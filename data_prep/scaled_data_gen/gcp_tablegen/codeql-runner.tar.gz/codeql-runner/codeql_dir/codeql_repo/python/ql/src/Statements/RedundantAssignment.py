class Spam:

    def __init__(self, eggs):
        eggs = eggs

