from sys import stdout

def main():
    stdout.write("Hello World!")
    
