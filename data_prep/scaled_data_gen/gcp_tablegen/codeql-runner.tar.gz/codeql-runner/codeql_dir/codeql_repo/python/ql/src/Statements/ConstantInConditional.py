if True:
    print "True is true!"

def limit(l):
    if l < -100:
        l = -100
    if 1 > 100:
        l = 100
    return l
