#!/usr/bin/env python

print("I'm actually a script you see ;)")
