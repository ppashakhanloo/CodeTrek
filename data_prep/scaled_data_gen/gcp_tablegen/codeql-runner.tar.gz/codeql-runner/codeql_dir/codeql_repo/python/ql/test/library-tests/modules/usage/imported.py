def func():
    pass

if __name__ == "__main__":
    print("I could have done something interesting...")
    print("but I didn't")
