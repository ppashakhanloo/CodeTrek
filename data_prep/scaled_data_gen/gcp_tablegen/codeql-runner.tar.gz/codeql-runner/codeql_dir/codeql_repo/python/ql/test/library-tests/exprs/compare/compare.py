
a < b < c

x in y
x not in y
x is y
x is not y
x < y
x > y
x >= y
x <= y
x == y
x != y
