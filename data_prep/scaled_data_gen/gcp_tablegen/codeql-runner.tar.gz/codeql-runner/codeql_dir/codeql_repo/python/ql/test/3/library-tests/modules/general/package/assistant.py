
class Wrong(object):
	pass

e = Wrong()

f = 1