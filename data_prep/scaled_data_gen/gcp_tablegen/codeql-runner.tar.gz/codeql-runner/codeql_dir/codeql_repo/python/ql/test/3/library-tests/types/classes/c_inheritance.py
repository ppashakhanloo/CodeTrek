
class MyList(list):
    pass
    
class MyDict(dict):
    pass
