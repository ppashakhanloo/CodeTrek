import sqlite3.dump
