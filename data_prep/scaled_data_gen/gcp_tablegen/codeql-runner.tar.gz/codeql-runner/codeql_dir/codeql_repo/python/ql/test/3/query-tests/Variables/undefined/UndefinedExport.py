

__all__ = [ "x", "y", "z", "module", "w" ]

x = 1
if 0:
    y = 2

import package.module

def init():
    global w
    w = 1

init()
