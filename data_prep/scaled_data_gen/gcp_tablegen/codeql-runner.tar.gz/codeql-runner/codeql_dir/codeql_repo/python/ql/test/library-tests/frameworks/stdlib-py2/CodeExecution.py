# exec statement is Python 2 specific
exec "print(42)"  # $getCode="print(42)"
