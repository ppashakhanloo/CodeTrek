import unittest

class FooTest(unittest.TestCase):
    def test_valid(self):
        pass
