# This is running under some unknown framework, but is clearly a test!

def test_foo():
    assert True
