
#Half Surrogate pairs
u'[\uD800-\uDBFF][\uDC00-\uDFFF]'
#Outside BMP
u'[\U00010000-\U0010ffff]'

#Troublesome format strings
u'{}\r{}{:<{width}}'
u'{}\r{}{:<{}}'
