0.058823529630899429


1e-06
.9999999
0xffffff
1e10
0o777
1.
2.79252680
0x0001000
4987312561856745907287624786230562734672583763984576267

'''d'''
''
""
"'"
"""efwb
onv
8979
"""
'0'
'None'

n = None
l = []
d = {}

class C(object):

    def meth(self):
        pass

    @classmethod
    def cmeth(cls):
        pass

    @staticmethod
    def smeth():
        pass