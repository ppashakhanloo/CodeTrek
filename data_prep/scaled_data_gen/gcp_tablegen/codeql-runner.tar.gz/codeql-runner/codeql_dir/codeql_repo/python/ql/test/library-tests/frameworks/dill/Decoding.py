import dill

dill.loads(payload)  # $decodeInput=payload decodeOutput=Attribute() decodeFormat=dill decodeMayExecuteInput
