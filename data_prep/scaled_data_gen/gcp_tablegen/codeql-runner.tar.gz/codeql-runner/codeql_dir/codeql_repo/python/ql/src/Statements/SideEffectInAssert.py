assert subprocess.call(['run-backup']) == 0
