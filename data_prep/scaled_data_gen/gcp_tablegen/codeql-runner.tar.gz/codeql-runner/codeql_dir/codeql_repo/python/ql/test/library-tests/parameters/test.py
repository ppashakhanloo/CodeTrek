
def f(a, b:str, c=None, d:int=True):
    pass

def g(*args:Tuple[int], **kwargs:Dict[str, int]):
    pass
