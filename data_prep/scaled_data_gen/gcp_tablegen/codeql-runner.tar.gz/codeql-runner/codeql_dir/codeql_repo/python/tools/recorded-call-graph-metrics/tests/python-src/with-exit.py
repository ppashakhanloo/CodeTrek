import sys

print("will exit now")

sys.exit()
