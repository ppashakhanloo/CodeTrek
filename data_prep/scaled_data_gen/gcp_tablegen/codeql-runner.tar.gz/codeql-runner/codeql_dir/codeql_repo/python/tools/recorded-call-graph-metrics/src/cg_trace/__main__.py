import sys

from cg_trace.main import main

sys.exit(main())
