foo = "foo"
bar = "bar"
baz = "baz"
# When `__all__` is not defined, names starting with underscore is not imported with `from <module> import *`
_qux = "qux"
