import imported

if __name__ == "__main__":
    imported.func()
    print('Done')
