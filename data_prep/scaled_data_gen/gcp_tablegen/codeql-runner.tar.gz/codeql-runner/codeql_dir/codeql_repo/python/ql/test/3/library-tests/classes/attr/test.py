

class DerivedFromBuiltin(list):

    def meth5(self):
        pass
