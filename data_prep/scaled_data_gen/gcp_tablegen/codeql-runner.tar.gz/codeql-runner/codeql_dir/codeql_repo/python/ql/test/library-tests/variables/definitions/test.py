
#ODASA-4153
def fail5(t):
    x, y = t
    return x
