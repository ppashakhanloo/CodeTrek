From Tornado 6.0 Python 3.5+ is [required](https://www.tornadoweb.org/en/stable/index.html#installation)

https://www.tornadoweb.org/en/stable/guide/structure.html#handling-request-input
