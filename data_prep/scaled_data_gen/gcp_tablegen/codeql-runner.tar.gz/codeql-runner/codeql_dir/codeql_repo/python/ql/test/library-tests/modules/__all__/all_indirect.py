# I (@RasmusWL) have not seen anyone use this pattern in real code,
# so this example is only included for completeness.
foo = "foo"
bar = "bar"
baz = "baz"


temp = ["foo", "bar"]
__all__ = temp
