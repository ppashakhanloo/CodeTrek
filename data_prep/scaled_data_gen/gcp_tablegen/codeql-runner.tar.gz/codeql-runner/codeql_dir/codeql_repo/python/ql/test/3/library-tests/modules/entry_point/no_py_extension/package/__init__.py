print(__file__.split("entry_point")[1])
from . import package_main
