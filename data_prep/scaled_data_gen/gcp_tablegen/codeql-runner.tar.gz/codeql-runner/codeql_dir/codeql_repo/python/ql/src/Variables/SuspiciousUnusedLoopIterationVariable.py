
#
def test():
    for t in [TypeA, TypeB]:
        x = TypeA()
        run_test(x)
