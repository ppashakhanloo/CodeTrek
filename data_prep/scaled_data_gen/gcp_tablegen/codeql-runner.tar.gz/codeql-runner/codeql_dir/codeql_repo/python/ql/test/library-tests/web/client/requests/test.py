import requests

requests.get('example.com')
requests.post('example.com')
