print("builtins test")
len("bar")
l = list()
l.append(42)

import sys
sys.getdefaultencoding()

r = range(10)
