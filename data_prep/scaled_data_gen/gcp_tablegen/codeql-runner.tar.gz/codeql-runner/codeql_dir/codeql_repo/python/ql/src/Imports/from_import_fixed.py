import sys

def main():
    sys.stdout.write("Hello World!")
