print(__file__.split("entry_point")[1])
message = "Hello world!"
