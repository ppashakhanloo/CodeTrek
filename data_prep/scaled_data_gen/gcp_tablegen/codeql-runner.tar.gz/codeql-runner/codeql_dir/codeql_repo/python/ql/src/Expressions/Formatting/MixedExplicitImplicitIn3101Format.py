def illegal_format():
    "{} {1}".format("spam", "eggs")
