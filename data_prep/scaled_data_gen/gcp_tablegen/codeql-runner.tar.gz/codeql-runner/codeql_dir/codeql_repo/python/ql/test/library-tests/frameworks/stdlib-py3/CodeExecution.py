import builtins

# exec being part of builtins is Python 3 only
builtins.exec("print(42)")  # $getCode="print(42)"
