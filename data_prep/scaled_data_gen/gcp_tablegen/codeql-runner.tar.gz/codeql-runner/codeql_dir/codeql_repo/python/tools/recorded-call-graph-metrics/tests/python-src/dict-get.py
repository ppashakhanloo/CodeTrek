d = dict()

d.get("foo") or d.get("bar")
