import subprocess
subprocess.call(['run-backup'])

class TestCase:
    pass

class MyTest(TestCase):
    pass
