This directory contains [experimental](../../../../docs/experimental.md) CodeQL queries and libraries.
