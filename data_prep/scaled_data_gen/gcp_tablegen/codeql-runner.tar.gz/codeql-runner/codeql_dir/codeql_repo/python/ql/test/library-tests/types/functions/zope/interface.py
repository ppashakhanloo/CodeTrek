#Fake zope.interface Module

class InterfaceClass(object):
    pass

Interface = InterfaceClass()
