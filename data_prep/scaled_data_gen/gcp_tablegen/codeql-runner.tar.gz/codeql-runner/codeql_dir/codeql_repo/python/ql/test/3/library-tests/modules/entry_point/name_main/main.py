print(__file__)
import module
import package
import namespace_package
import namespace_package.namespace_package_main

if __name__ == '__main__':
   print(module.message)
