def foo():
    print('foo')

def bar():
    print('bar')

foo()
bar()

foo(); bar()
