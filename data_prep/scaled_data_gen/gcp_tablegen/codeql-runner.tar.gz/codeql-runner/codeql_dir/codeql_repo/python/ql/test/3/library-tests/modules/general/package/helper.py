from __future__ import absolute_import
from assistant import e
import sys

d = 4

g = 7


from . import assistant