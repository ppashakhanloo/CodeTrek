
def print_fellows(fellows):
    for f in fellows:
        print(f)
        
#...

def print_records():
    #...
    print_fellows(fellows)
    print_members(members)
    print_associates(associates)
    print_students(students)