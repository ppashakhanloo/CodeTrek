import six

# Check that some expected attributes are visible -- this is the reason we added stubs in
# the first place! If this works, we're happy!
six.moves
six.moves.range
six.moves.zip
six.moves.http_client.HTTPConnection
six.moves.urllib.parse.urlsplit
