#! /usr/bin/python3
print(__file__)
import module
import package
import namespace_package
import namespace_package.namespace_package_main
print(module.message)
