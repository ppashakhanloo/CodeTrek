class TestCase:
    pass

class MyTest(TestCase):

    def test_1(self):
        pass

    def test_2(self):
        pass
