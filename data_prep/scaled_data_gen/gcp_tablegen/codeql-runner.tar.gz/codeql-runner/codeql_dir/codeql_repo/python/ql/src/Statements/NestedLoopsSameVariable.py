
for var in range(3):
    for var in range(3):
        pass
    print (var) # Prints 2 2 2 not 0 1 2 as might be expected

