
def main():
    try:
        process()
    except Exception as ex:
        print(ex)
        exit(1)
