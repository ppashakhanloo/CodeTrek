import socket

sock = socket.socket()
print(sock.getsockname())
