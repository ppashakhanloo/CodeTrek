

dangerous = SOURCE
safe = "safe"

def dangerous_func():
    return SOURCE


safe2 = SOURCE
safe2 = "safe"
