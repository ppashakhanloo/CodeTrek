
def kwonly(p0, *, kw=None):
    return kw
