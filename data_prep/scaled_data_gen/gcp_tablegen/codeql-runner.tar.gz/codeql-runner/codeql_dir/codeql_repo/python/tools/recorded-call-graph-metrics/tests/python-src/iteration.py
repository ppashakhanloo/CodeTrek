for i in range(10):
    print(i)

[i + 1 for i in range(10)]
l = list(range(10))
[i + 1 for i in l]
[i + 1 for i in l]
