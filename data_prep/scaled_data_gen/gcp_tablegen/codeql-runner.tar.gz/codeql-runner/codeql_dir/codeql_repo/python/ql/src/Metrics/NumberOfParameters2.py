def print_membership(fellows, members, associates, students):
    for f in fellows:
        print(f)
    for m in members:
        print(m)
    for a in associates:
        print(a)
    for s in students:
        print(s)

def print_records():
    #...
    print_membership(fellows, members, associates, students)