def area(r):
    #if DEBUG:
    #   print("Computing area of %r" % r)
    return r.length * r.width
